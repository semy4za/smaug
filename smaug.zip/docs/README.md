# 🐉 Smaug

**Análise de dados em Lua, com a performance do C.**

Smaug é uma biblioteca que traz funcionalidades estilo Pandas para o Lua, usando
um backend em C otimizado conectado via LuaJIT FFI (zero-copy). O objetivo é uma
ferramenta de análise tabular **leve** o suficiente para edge computing, game
engines e IoT, com performance numérica próxima a NumPy.

---

## Por quê

Python + Pandas é a ferramenta padrão para dados tabulares, mas é pesado:
import lento, footprint alto e difícil de embarcar. Lua é o oposto — runtime de
~400KB, e o LuaJIT traz JIT + FFI nativo. Smaug junta os dois: **frontend Lua
expressivo, backend C rápido**.

## Stack

| Camada | Tecnologia | Responsabilidade |
|--------|-----------|------------------|
| Frontend | Lua 5.1 / LuaJIT | Classes `Series`/`DataSet`, API, metamétodos |
| Bridge | LuaJIT FFI | Passagem de dados zero-copy, chamadas nativas |
| Backend | C11 | Operações numéricas, malloc/free, loops SIMD-friendly |
| Build | Makefile / CMake | Portabilidade Linux/macOS/Windows |

## Alvos não-funcionais

| Aspecto | Alvo |
|---------|------|
| Footprint compilado | < 2 MB |
| Startup (require + init) | < 100 ms |
| Performance numérica | ≥ 80% de NumPy em operações grandes |
| Type safety | zero segfaults silenciosos |
| Compatibilidade de API | ~90% Pandas |

---

## Arquitetura em camadas

```
┌─────────────────────────────────────────────┐
│  Aplicação do usuário (Lua)                  │
│  local df = smaug.read_csv("dados.csv")      │
│  local total = df["salario"]:sum()           │
├─────────────────────────────────────────────┤
│  Frontend Lua                                │
│  Series, DataSet, metamétodos, validação     │
├─────────────────────────────────────────────┤
│  Bridge FFI (ffi.cdef + ffi.load + ffi.gc)   │
│  Assinaturas C, hooks de GC, sem lógica       │
├─────────────────────────────────────────────┤
│  Backend C (libsmaug.so)                │
│  Structs tipadas, arrays contíguos, bitmasks  │
└─────────────────────────────────────────────┘
```

Fluxo de uma chamada como `df["idade"]:sum()`: o `__index` do DataSet devolve a
`Series` da coluna, o método `:sum()` em Lua chama `C.smaug_f64_sum(ptr, ...)`
via FFI, o C executa o loop acumulador e devolve um `double` direto ao Lua.

## Formatos de dados suportados

O Smaug lê e escreve **quatro** formatos — e apenas estes:

| Formato | Fonte | Tipos |
|---------|-------|-------|
| **CSV** | `.csv` / `.tsv` | inferência heurística |
| **JSON** | `.json` (records ou columnar) | nativos do JSON |
| **XML** | `.xml` (convenção `row_tag`) | inferência heurística |
| **SQL** | SQLite (dependência opcional) | do schema |

Design completo em `Roadmap.md` (Fase 6). Ainda não implementados.

## Tipos de dados (dtypes)

O Smaug adota um conjunto curado de tipos, em camadas (detalhe em
`Roadmap.md` → "Sistema de tipos"):

| Camada | Tipos | Status |
|--------|-------|--------|
| Núcleo | `float64`, `int64`, `bool`, `string` | f64/i64/bool ✅; string (Fase 5, próxima) |
| Alto valor | `datetime`, `categorical` | pós-MVP |
| Otimização | `float32`, `int32`, `int8/16`, `uint*` | mesma API, storage estreito; só se necessário |

A classe `Series` abstrai o dtype: adicionar um tipo novo é registrar um
descritor + o backend C, sem mudar o código do usuário. Sem coerção implícita
entre tipos.

---

## Decisões de design

**Tipos separados, sem coerção implícita.** Cada tipo numérico tem sua própria
struct (`smaug_series_f64_t`, `smaug_series_i64_t`) e seu próprio conjunto de
funções. Sem casting silencioso — o usuário decide explicitamente. Evita classes
inteiras de bugs e elimina overhead de conversão nos loops.

**Null handling por bitmask paralelo.** Cada série carrega um array
`smaug_mask_t` (`uint8_t`) onde `0xFF` = válido e `0x00` = nulo (NA). É 8× mais
RAM que bit-packing, mas cache-friendly, sem complexidade bitwise, e funciona
para qualquer tipo (inteiros e strings não têm NaN nativo).

**Imutabilidade por padrão.** Operações (`add`, `mul`, `filter`, …) sempre
retornam uma série nova; nunca modificam in-place. Só `set`/`set_null`/`append`
mutam. Isso evita bugs de aliasing. A exceção são **views** (slices sem cópia),
que são read-only.

**Views são zero-copy e têm dono externo.** `smaug_f64_view(s, start, len)`
aponta para dentro do array da série-pai. A flag `external_alloc=true` impede que
o `free` da view libere a memória da pai — mas a view **não pode sobreviver** à
pai (use `clone` se precisar).

**Indexação 1-based no Lua, 0-based no C.** Convenção de cada mundo respeitada; a
conversão acontece no wrapper Lua.

**Memória manual no C, `ffi.gc` no Lua.** O backend controla seu próprio
malloc/free (sem overhead de GC). No Lua, cada struct retornado é registrado com
`ffi.gc(ptr, C.smaug_f64_free)` para limpeza automática.

---

## Estrutura do projeto

```
smaug/
├── include/
│   ├── smaug_types.h      # Tipos base (mask, metadata, structs) — zero funções
│   ├── smaug_core.h       # Lifecycle, get/set, append, smaug_free
│   ├── smaug_numeric.h    # Aritmética/reduções/comparações/sort/utils (f64+i64)
│   ├── smaug_bool.h       # Lógica booleana (Kleene)
│   └── smaug.h            # Umbrella (inclui os de operação)
├── src/
│   ├── smaug_core.c        # Lifecycle: create/free/clone/view, get/set, append
│   ├── smaug_ops_f64.c     # Operações float64
│   ├── smaug_ops_i64.c     # Operações int64
│   └── smaug_ops_bool.c    # Lógica booleana (Kleene)
├── docs/
│   ├── README.md           # Este arquivo
│   ├── API_Reference.md    # Referência da API C
│   ├── Build_and_Testing.md# Compilação e testes
│   └── Roadmap.md          # Fases futuras + design do frontend Lua
├── lua/
│   └── smaug/
│       └── ffi_loader.lua  # ✅ Ponte FFI: cdef completo + ffi.load
└── build/                  # Output da compilação (libsmaug.so)
```

A criar (ver `Roadmap.md`): resto do frontend (`core/series.lua`, `init.lua`),
`DataSet`, CSV I/O.

---

## Status rápido

| Camada | Status |
|--------|--------|
| Headers (5, separados por responsabilidade) | ✅ Completo e estável |
| Backend C — f64 (lifecycle + ops) | ✅ Completo |
| Backend C — i64 (lifecycle + ops) | ✅ Completo |
| Backend C — bool (lógica Kleene) | ✅ `smaug_ops_bool.c` |
| Sistema de build (`Makefile`) | ✅ Completo |
| Testes C (`test_ops` + `test_alloc` + `test_bool`) | ✅ Passam (Valgrind-clean) |
| Frontend Lua — `ffi_loader.lua` | ✅ Completo e validado |
| Frontend Lua — `Series` (f64 + i64) | ✅ Implementada (despacho por dtype) |
| Frontend Lua — `BoolSeries` + comparações + `filter` | ✅ Implementada |
| Frontend Lua — `DataSet` | ✅ Implementada (Fase 3) |
| Frontend Lua — `init.lua` | ✅ Entry point |
| Portabilidade Windows (`smaug_free` + PowerShell) | ✅ Build + testes no Windows |
| **Endurecimento (Fase 1.6)** | ⏳ **Em andamento — gate atual** |
| Tipo `string` (Tier 1) | ❌ Fase 5 (próxima, pré-requisito do I/O) |
| I/O — CSV + JSON (deploy) | ❌ Fase 6 |

> **Gate de qualidade.** Nenhuma fase nova começa antes de a anterior estar
> validada em nível "aviação": testes sistemáticos, property-based, e cobertura
> **medida** (gcov) ≥ 90%. A Fase 1.6 (endurecimento) é o gate atual; ver
> `Roadmap.md`.
